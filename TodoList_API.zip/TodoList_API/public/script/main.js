function refresh(){
    $("#todotable").empty();
    $.ajax({
            url : "/todos",
            success : function(res){
                res.forEach(function(todo, idx){
                    $("#todotable").append(`<tr>
                                        <th>${ idx + 1 }</th>
                                        <td>${ todo.description}</td>
                                        <td>${ todo.completed }</td>
                                        <td><button todos-id="${ todo._id }" class="btn btn-warning">Edit </button></td>
                                        <td><button todos-id="${ todo._id }" class="btn btn-danger">Delete </button></td>
                                    </tr>`)
                })
               
            },
            error : function(err){
                console.log("Error ", err)
            }
       }) 
};
function addHandler(){
    $.ajax({
        url : "/todos",
        method : "post",
        todos : JSON.stringify({
            taskID : $("#task_id").val(),
            description : $("#description").val(),
            completed : $("#completed").val()
        }),
        contentType : "application/json",
        dataType : "json",
        success : function(res){
            refresh();
            console.log(res);
            $("#task_id").val("");
            $("#description").val("");
            $("#completed").val("");
        },error : function(err){
            console.log("Error ", err)
        }
    })
};
// grid button handlers
function editHandler(evt){
    //alert(evt.target.getAttribute("todos-id"));
    $.ajax({
        method : "get",
        url : "/edit/"+evt.target.getAttribute("todos-id"),
        success : function(tododata){
            //alert(JSON.stringify(tododata));
            $("#edit_task_id").val(tododata.taskID);
            $("#edit_description").val(tododata.description);
            $("#edit_completed").val(tododata.completed);
            $("#edit_todoid").val(tododata._id);
            $("#updatebox").show(500);
        },
        error : function(error){
            console.log("Erroe ", error);
        }
    })
}
function deleteHandler(evt){
    //alert(evt.target.getAttribute("todos-id"));
    $.ajax({
        method : "delete",
        url : "/delete/"+evt.target.getAttribute("todos-id"),
        success : function(res){
            refresh();
            console.log(res.message);
        },
        error : function(error){
            console.log("Error ", error);
        }
    })
}

function updateHandler(){
    $.ajax({
        url : "/edit"+$("#edit_todoid").val(),
        method : "post",
        todos : JSON.stringify({
            taskID : $("#edit_task_id").val(),
            description : $("#edit_description").val(),
            completed : $("#edit_completed").val()
        }),
        contentType : "application/json",
        dataType : "json",
        success : function(res){
            refresh();
            console.log(res);
            $("#edit_task_id").val("");
            $("#edit_description").val("");
            $("#edit_completed").val("");
            $("#updatebox").hide(500);
        },error : function(err){
            console.log("Error ", err)
        }
    })
}
$(function(){
    refresh();
    $("#updatebox").hide();
    $("#addbtn").on("click", addHandler);
    //add event listeners on grid buttons
    $("#todotable").on("click", ".btn-warning", editHandler);
    $("#todotable").on("click", ".btn-danger", deleteHandler);
    $("#editbtn").on("click", updateHandler);
})

/*
let xhr = new XMLHttpRequest();
    xhr.addEventListener("readystatechange", changeHandler);
function changeHandler(evt){
    console.log(xhr.readyState);
    if(xhr.readyState === 4){
        console.log(xhr.readyState);
        console.log(xhr.responseText);
    }else{
        console.log(xhr.readyState);
    }
}

document.addEventListener("DOMContentLoaded", function(){
    xhr.open("get", "/todos", true);
    xhr.send()
})

function btnClickHandler(){
    xhr.send()
}
*/