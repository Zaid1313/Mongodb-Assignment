//import mongoose
const { default: mongoose } = require("mongoose");

//db model
//todo model
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Todolist = mongoose.model("Todolist",Schema({
    id : ObjectId,
    taskID:Number,
    description:String,
    completed:String
    /*taskID:{type:Number,required:true},
    description:{type:String,required:true},
    completed:{type:Boolean,default:false}*/
}));

//export this file 
module.exports.Todolist = Todolist;
