    // Tests that a new todo item is successfully added
    it('test_add_todo_successfully', () => {
        // Arrange
        const taskID = '123';
        const description = 'Test todo';
        const completed = false;
        // const refreshSpy = jest.spyOn(global, 'refresh').mockImplementation(() => {});
        const ajaxSpy = jest.spyOn($, 'ajax').mockImplementation(({ success }) => success());
        const taskIDInput = document.createElement('input');
        taskIDInput.id = 'task_id';
        taskIDInput.value = taskID;
        const descriptionInput = document.createElement('input');
        descriptionInput.id = 'description';
        descriptionInput.value = description;
        const completedInput = document.createElement('input');
        completedInput.id = 'completed';
        completedInput.value = completed;
        document.body.appendChild(taskIDInput);
        document.body.appendChild(descriptionInput);
        document.body.appendChild(completedInput);

        // Act
        addHandler();

        // Assert
        expect(ajaxSpy).toHaveBeenCalledWith({
            url: '/todos',
            method: 'post',
            todos: JSON.stringify({ taskID, description, completed }),
            contentType: 'application/json',
            dataType: 'json',
            success: expect.any(Function),
            error: expect.any(Function)
        });
        expect(refreshSpy).toHaveBeenCalled();
        expect(taskIDInput.value).toBe('');
        expect(descriptionInput.value).toBe('');
        expect(completedInput.value).toBe('');

        // Cleanup
        taskIDInput.remove();
        descriptionInput.remove();
        completedInput.remove();
        refreshSpy.mockRestore();
        ajaxSpy.mockRestore();
    });