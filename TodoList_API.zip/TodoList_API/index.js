const express = require('express');
//apllication object
const app = express();
const config = require("./config/config.json");
const mongoose = require("mongoose");
const routes = require('./routes/todo.routes');
//import model
//const Todolist = require("./model/todolist.model").Todolist;

const dburl = `mongodb+srv://${config.dbuser}:${config.dbpass}@${config.dbcluster}.${config.dbstring}.mongodb.net/${config.dbname}?retryWrites=true&w=majority`

//middlewares 
app
.use(express.static(__dirname+"/public"))
.use(express.json())
.use(routes);

//connet mongoose with dburl
mongoose.connect(dburl)
.then(() =>console.log("DB Connected"))
.catch(error => console.log("Error ", error));


app.listen(config.port, config.host, error => {
    if(error) console.log("Error ",error);
    else console.log(`server is now running on ${config.host}:${config.port}`)
});