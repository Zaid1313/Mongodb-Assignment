const express = require("express");
const { Todolist } = require("../model/todolist.model");
const routes = express.Router();
//READ Request
routes.get("/todos", (req, res) => {
    //res.send("request on data route received");
    Todolist.find().then(dbres => {
        res.send(dbres);
    });
});

//CREATE
routes.post("/todos", (req, res) =>{
    console.log(req.body);
    let todo = new Todolist(req.body);
    todo.save()
    .then(dbres => res.send({ "message" : dbres.description+" was added" }))
    .catch(error => console.log("Error ", error));
})

//READ BEFORE UPDATE
routes.get("/edit/:todoid", (req, res) =>{
    Todolist.findById(req.params.todoid)
    .then(dbres => res.send(dbres))
    .catch(error => console.log("Error ", error));
});

//UPDATE
routes.post("/edit/:todoid", (req, res) =>{
    Todolist.findByIdAndUpdate(req.params.todoid, req.body)
    .then(dbres => res.send({"message":"todo lists updated"}))
    .catch(error => console.log("error", error));
    /*Todolist.findById(req.params.todoid)
    .then(dbres => res.send(dbres))
    .catch(error => console.log("Error ", error)); */
});

//DELETE
routes.delete("/delete/:todoid", (req, res) => {
    Todolist
    .findByIdAndDelete(req.params.todoid)
    .then(dbres => res.send({"message":"deleted "+dbres.description}))
    .catch(error => {
        console.log("Error ", error);
    });
});

//export routes
module.exports = routes;


